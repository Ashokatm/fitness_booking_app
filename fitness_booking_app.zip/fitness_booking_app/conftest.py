import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import engine, Base
from seed_data import seed_data

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    seed_data()

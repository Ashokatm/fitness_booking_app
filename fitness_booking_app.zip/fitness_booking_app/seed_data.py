from datetime import datetime
from app.database import SessionLocal, convert_timezone
from app.models import Class
from app.schemas import ClassCreate

def seed_data():
    db = SessionLocal()
    try:
        classes_data = [
            ClassCreate(name="Yoga", date_time=datetime(2025, 6, 27, 10, 0), instructor="Priya", available_slots=10),
            ClassCreate(name="Zumba", date_time=datetime(2025, 6, 27, 12, 0), instructor="Rahul", available_slots=15),
            ClassCreate(name="HIIT", date_time=datetime(2025, 6, 28, 9, 0), instructor="Anita", available_slots=8),
        ]
        for class_data in classes_data:
            db_class = Class(**class_data.model_dump())
            db.add(db_class)
        db.commit()
        print("Seeded data successfully")
    except Exception as e:
        db.rollback()
        print(f"Error seeding data: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    seed_data()

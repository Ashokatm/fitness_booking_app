from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from typing import List
from app.database import SessionLocal, engine, get_db, convert_timezone  # Updated import
from app.schemas import ClassCreate, ClassResponse, BookingCreate, BookingResponse
from app.crud import get_classes, create_class, book_class, get_bookings_by_email
import logging

app = FastAPI()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Dependency
def get_db_session():
    db = next(get_db())
    try:
        yield db
    finally:
        db.close()

@app.get("/classes", response_model=List[ClassResponse])
def read_classes(db: Session = Depends(get_db_session), timezone: str = "Asia/Kolkata"):
    classes = get_classes(db, timezone)
    return classes

@app.post("/book", response_model=BookingResponse)
def create_booking(booking: BookingCreate, db: Session = Depends(get_db_session)):
    try:
        return book_class(db, booking)
    except ValueError as e:
        logger.error(f"Booking error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/bookings", response_model=List[BookingResponse])
def read_bookings(email: str, db: Session = Depends(get_db_session)):
    if not email:
        raise HTTPException(status_code=400, detail="Email is required")
    bookings = get_bookings_by_email(db, email)
    if not bookings:
        raise HTTPException(status_code=404, detail="No bookings found")
    return bookings

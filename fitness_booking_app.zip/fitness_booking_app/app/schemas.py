from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from typing import List

class ClassCreate(BaseModel):
    name: str
    date_time: datetime
    instructor: str
    available_slots: int

    @field_validator("available_slots")
    @classmethod
    def validate_available_slots(cls, v):
        if v < 0:
            raise ValueError("Available slots cannot be negative")
        return v

class ClassResponse(ClassCreate):
    id: int
    timezone: str

class BookingCreate(BaseModel):
    class_id: int
    client_name: str
    client_email: str

class BookingResponse(BookingCreate):
    id: int

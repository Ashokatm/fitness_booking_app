from sqlalchemy.orm import Session
from .models import Class, Booking  # Updated import
from .schemas import ClassCreate, BookingCreate
from .database import convert_timezone
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_classes(db: Session, timezone: str = "Asia/Kolkata"):
    classes = db.query(Class).all()
    for cls in classes:
        cls.date_time = convert_timezone(cls.date_time, cls.timezone, timezone)
    return classes

def create_class(db: Session, class_data: ClassCreate):
    db_class = Class(**class_data.model_dump())
    db.add(db_class)
    db.commit()
    db.refresh(db_class)
    logger.info(f"Created class {db_class.id}")
    return db_class

def book_class(db: Session, booking_data: BookingCreate):
    db_class = db.query(Class).filter(Class.id == booking_data.class_id).first()
    print(f"Debug: Class {booking_data.class_id} - {db_class}, slots: {db_class.available_slots if db_class else None}")
    if not db_class or db_class.available_slots <= 0:
        raise ValueError("No available slots or class not found")
    db_booking = Booking(**booking_data.model_dump())
    db_class.available_slots -= 1
    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    logger.info(f"Booked class {booking_data.class_id} for {booking_data.client_email}")
    return db_booking


def get_bookings_by_email(db: Session, email: str):
    return db.query(Booking).filter(Booking.client_email == email).all()

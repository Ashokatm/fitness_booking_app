import pytest

def test_read_classes(client):
    response = client.get("/classes?timezone=Asia/Kolkata")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 3  # Assuming 3 classes are seeded

def test_book_class_success(client):
    response = client.post("/book", json={"class_id": 1, "client_name": "John Doe", "client_email": "john@example.com"})
    if response.status_code == 400 and "No available slots" in response.json()["detail"]:
        pytest.skip("No available slots, test skipped")
    assert response.status_code == 200
    data = response.json()
    assert data["class_id"] == 1

def test_book_class_no_slots(client):
    # Book all slots for class 1 (assuming 10 slots)
    for _ in range(10):
        client.post("/book", json={"class_id": 1, "client_name": "Test User", "client_email": f"test{_}@example.com"})
    response = client.post("/book", json={"class_id": 1, "client_name": "John Doe", "client_email": "john@example.com"})
    assert response.status_code == 400
    assert "No available slots" in response.json()["detail"]

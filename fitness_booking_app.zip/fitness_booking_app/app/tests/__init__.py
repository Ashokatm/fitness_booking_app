# Empty __init__.py to mark tests as a package
# Test discovery will automatically find test_api.py
pass
